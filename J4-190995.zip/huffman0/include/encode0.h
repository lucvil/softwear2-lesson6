#ifndef HUFFMAN_ENCODE0_H
#define HUFFMAN_ENCODE0_H

int encode(const char *filename);

#endif
