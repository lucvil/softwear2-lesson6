#ifndef HUFFMAN_ENCODE1_H
#define HUFFMAN_ENCODE1_H

int encode(const char *filename1 , const char *control);

#endif
